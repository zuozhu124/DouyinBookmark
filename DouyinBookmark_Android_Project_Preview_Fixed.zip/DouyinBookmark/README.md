# 抖音收藏助手（中国版抖音）

一个本地优先的 Android App：保存中国版抖音分享链接、可公开读取的页面标题/封面信息，并在以后打开原视频。不会下载视频文件，也不绕过登录、权限或平台访问控制。

## 当前版本功能
- 粘贴分享文本或 URL，识别 `douyin.com` / `iesdouyin.com` 域名
- 尝试读取无需登录即可访问的页面标题、封面及最终跳转地址
- 解析失败时仍保存原始分享链接
- 本地收藏列表、搜索、删除、打开原视频
- 接收 Android 分享菜单中的纯文本链接
- 本地 SharedPreferences JSON 存储，不需要账号或自建服务器

## 构建 APK
1. 安装 Android Studio（建议稳定版）及 Android SDK Platform 35。
2. 用 Android Studio 打开本项目根目录 `DouyinBookmark`。
3. 等待 Gradle 同步完成。
4. 选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. APK 通常生成在 `app/build/outputs/apk/debug/app-debug.apk`。

也可在已安装 Android SDK 和 Gradle 的环境中执行：
`gradle assembleDebug`

## 重要说明
- 当前交付为可导入 Android Studio 的完整首版源码项目；生成 APK 需要 Android SDK/Gradle 构建环境。
- 抖音可能对短链接跳转、网页元数据或访问频率进行限制；此时应用会保留原始链接，标题可显示为“抖音视频”。
- 原视频删除、设为私密、地区/登录限制或链接失效时，收藏助手无法保证仍可播放。
- 应用仅保存链接和公开元数据，不提供视频下载或绕过访问控制。
