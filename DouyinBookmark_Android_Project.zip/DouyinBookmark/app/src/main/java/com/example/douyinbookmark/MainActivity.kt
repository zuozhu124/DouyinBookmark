package com.example.douyinbookmark

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF151923)
private val Accent = Color(0xFF7C5CFF)
private val Muted = Color(0xFF9299AA)

data class Bookmark(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val url: String,
    val cover: String = "",
    val addedAt: Long = System.currentTimeMillis()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val initial = extractSharedText(intent)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent,
                    background = Bg,
                    surface = Panel,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                BookmarkApp(initial)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    private fun extractSharedText(i: Intent?): String {
        if (i == null) return ""
        return when (i.action) {
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            Intent.ACTION_VIEW -> i.dataString.orEmpty()
            else -> ""
        }
    }
}

@Composable
private fun BookmarkApp(initialText: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("bookmarks", 0) }
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf(initialText) }
    var search by remember { mutableStateOf("") }
    var list by remember { mutableStateOf(loadBookmarks(prefs.getString("items", "[]") ?: "[]")) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    fun persist(items: List<Bookmark>) {
        list = items
        prefs.edit().putString("items", JSONArray().apply {
            items.forEach { b ->
                put(JSONObject().apply {
                    put("id", b.id); put("title", b.title); put("url", b.url)
                    put("cover", b.cover); put("addedAt", b.addedAt)
                })
            }
        }.toString()).apply()
    }

    fun addBookmark() {
        val raw = input.trim()
        val url = extractDouyinUrl(raw)
        if (url == null) {
            message = "请输入有效的中国版抖音分享链接"
            return
        }
        if (list.any { it.url == url }) {
            message = "这个视频已经收藏过了"
            return
        }
        busy = true
        message = "正在读取公开视频信息…"
        scope.launch {
            val meta = withContext(Dispatchers.IO) { fetchPublicMetadata(url) }
            val item = Bookmark(
                title = meta.first.ifBlank { "抖音视频" },
                url = meta.second.ifBlank { url },
                cover = meta.third
            )
            persist(listOf(item) + list)
            input = ""
            busy = false
            message = if (meta.first.isBlank()) "已保存链接（未能读取公开标题，仍可打开原视频）" else "收藏成功"
        }
    }

    val visible = list.filter {
        it.title.contains(search, true) || it.url.contains(search, true)
    }

    Column(
        Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(Accent.copy(alpha = .18f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Bookmark, null, tint = Accent) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("抖音收藏助手", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("你的私人视频书签库", fontSize = 12.sp, color = Muted)
            }
            Text("${list.size} 条", color = Accent, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(22.dp))
        Text("添加视频", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        Column(
            Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("粘贴抖音分享链接…", color = Muted) },
                leadingIcon = { Icon(Icons.Default.Link, null, tint = Muted) },
                minLines = 2,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Accent,
                    unfocusedBorderColor = Color(0xFF303747),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = Accent
                )
            )
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = { addBookmark() },
                enabled = !busy && input.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) {
                if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                else Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(8.dp))
                Text(if (busy) "正在处理" else "保存到收藏库", fontWeight = FontWeight.SemiBold)
            }
            if (message.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(message, color = Muted, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(22.dp))
        Text("我的收藏", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("搜索标题或链接", color = Muted) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent,
                unfocusedBorderColor = Color(0xFF303747),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )
        Spacer(Modifier.height(10.dp))
        if (visible.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Bookmark, null, tint = Color(0xFF3A4050), modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(if (list.isEmpty()) "还没有收藏视频" else "没有找到相关视频", color = Muted)
                    Text("复制抖音分享链接，粘贴后即可保存", color = Color(0xFF626A7B), fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 18.dp)
            ) {
                items(visible, key = { it.id }) { item ->
                    BookmarkCard(
                        item = item,
                        onOpen = {
                            val open = Intent(Intent.ACTION_VIEW, Uri.parse(item.url))
                            context.startActivity(open)
                        },
                        onDelete = { persist(list.filterNot { it.id == item.id }) }
                    )
                }
            }
        }
        Text(
            "仅保存视频链接与公开信息；原视频可用性取决于抖音页面状态。",
            color = Color(0xFF626A7B), fontSize = 10.sp,
            modifier = Modifier.padding(bottom = 10.dp)
        )
    }
}

@Composable
private fun BookmarkCard(item: Bookmark, onOpen: () -> Unit, onDelete: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).background(Accent.copy(alpha = .16f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Bookmark, null, tint = Accent) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 2)
            Spacer(Modifier.height(4.dp))
            Text(item.url, color = Muted, fontSize = 10.sp, maxLines = 1)
        }
        IconButton(onClick = onOpen) {
            Icon(Icons.Default.OpenInNew, "打开原视频", tint = Accent)
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Default.Delete, "删除收藏", tint = Muted)
        }
    }
}

private fun extractDouyinUrl(raw: String): String? {
    val candidate = Regex("""https?://[^\s]+""").find(raw)?.value
        ?.trimEnd('.', ',', '，', ')', '）', '。') ?: return null
    return try {
        val uri = Uri.parse(candidate)
        val host = uri.host?.lowercase().orEmpty()
        val allowed = host == "douyin.com" || host.endsWith(".douyin.com") ||
            host == "iesdouyin.com" || host.endsWith(".iesdouyin.com")
        if (uri.scheme !in listOf("http", "https") || !allowed) null else candidate
    } catch (_: Exception) { null }
}

private fun fetchPublicMetadata(original: String): Triple<String, String, String> {
    var connection: HttpURLConnection? = null
    return try {
        connection = (URL(original).openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = true
            connectTimeout = 7000
            readTimeout = 7000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            setRequestProperty("Accept", "text/html,application/xhtml+xml")
        }
        val finalUrl = connection.url.toString()
        val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText().take(1_500_000) }
        fun meta(vararg patterns: String): String {
            for (p in patterns) {
                val match = Regex(p, setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)
                if (match != null) return match.groupValues.getOrNull(1).orEmpty()
            }
            return ""
        }
        val title = meta(
            """<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']*)""",
            """<meta[^>]+content=["']([^"']*)["'][^>]+property=["']og:title["']""",
            """<title[^>]*>(.*?)</title>"""
        ).replace("&quot;", "\"").replace("&amp;", "&").replace("&#39;", "'").trim()
        val cover = meta(
            """<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']*)""",
            """<meta[^>]+content=["']([^"']*)["'][^>]+property=["']og:image["']"""
        )
        Triple(title, finalUrl, cover)
    } catch (_: Exception) {
        Triple("", original, "")
    } finally {
        connection?.disconnect()
    }
}

private fun loadBookmarks(json: String): List<Bookmark> {
    return try {
        val arr = JSONArray(json)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Bookmark(
                id = o.optString("id", UUID.randomUUID().toString()),
                title = o.optString("title", "抖音视频"),
                url = o.optString("url"),
                cover = o.optString("cover"),
                addedAt = o.optLong("addedAt")
            )
        }.filter { it.url.isNotBlank() }
    } catch (_: Exception) { emptyList() }
}
